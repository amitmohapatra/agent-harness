# Writing rules for every page (read before writing)

Source of truth: the main branches checked out at /var/tmp/clean/{agent-harness, agent-memory-service,
agent-runs, agent-contracts, bifrost-sdk}. Read the code and docs there. Do not use any other checkout.

## Who reads these pages
Two kinds of readers on the same page:
- non-developers (product, managers, support, business): they read the top part only;
- developers: they read everything, including code.

## Page layout (every page, same order)
1. `# Title` (plain, 2–5 words)
2. `> **In short:**` 2–3 lines anyone can understand. No jargon.
3. `**Who should read this:**` one line.
4. `## What it is` and `## Why you need it`: plain words, a real-life example (a shop, a bank, a
   support desk, an HR team).
5. `## How it works`: steps in numbered order. A simple diagram (```mermaid```) where it helps.
6. `## How to use it`: every way to do it (Way 1 wrapped, Way 2 blocks, SDK only, each framework
   where it differs), each with a short, real code example.
7. `## Options and settings`: a table with each argument/setting, default, and what it does.
8. `## Good to know`: limits, common mistakes, what happens when something fails.
9. `## Related pages`: links to the other pages by their file name.
10. `**Source in the code:**` the repo paths this page was written from (docs and code).

Skip a section only when it truly does not apply.

## Language
- Simple English, the way a senior Indian engineer explains to a new joiner: clear, friendly,
  direct. Short sentences. One idea per sentence. Explain any technical word the first time.
- Plain words: "use" not "leverage", "help" not "empower", "easy" not "seamless".
- Never use these words: seamless, robust, leverage, delve, empower, unlock, elevate,
  cutting-edge, game-changer, holistic, synergy, journey, landscape, tapestry, crucial,
  comprehensive, effortlessly, "in today's world", "whether you're ... or ...", "let's dive in".
- No long dashes (—). Use a full stop, comma, colon or brackets.
- No marketing tone, no exaggeration, no emojis.
- American or British idioms are not needed. Do not write caricature Indian phrases either
  ("kindly do the needful", "revert back"). Just plain, polite English.
- Use "you" for the reader. Use "we" for the Trellis team.
- Numbers as digits. Code names in `backticks`.

## Accuracy (most important)
- Every function, argument, setting, environment variable, command and file path must exist
  on main. Copy code examples from the repo's docs or examples/ and adapt them only a little.
  If you are not sure something exists, check with grep. Never invent a name.
- Cover every feature in your source docs. When you finish, list in `_coverage-<section>.md`
  each feature heading from the source docs and the page that covers it.
- Background agents (start_async_task, task inbox, background_task events) are NOT on main.
  Do not document them. If a source mentions them, leave it out.
- Do not put model IDs, keys or internal hostnames in examples. Use `"openai/gpt-4.1-mini"` as
  the repo's own examples do.

## Optional parts (say this clearly everywhere)
- Trellis is gateway-neutral. Do NOT present Bifrost as "the" gateway. Present model access as
  ROUTES (harness docs/configuration.md, "where a model name goes"; `trellis.harness.gateways`):
  1. `openai-compatible`: any OpenAI-compatible endpoint or gateway (OpenAI, OpenRouter, a
     LiteLLM proxy, Ollama, vLLM, llama.cpp, Anthropic/Gemini compatible endpoints; Google/AWS
     logins via `LLM_AUTH`);
  2. `provider-sdk`: no endpoint, the provider's own SDK and key;
  3. `bifrost`: one built-in route that also gives that gateway's extras (its MCP tools, Code
     Mode, stored prompts, skills, cost/dollar budgets, fallbacks);
  4. your own route: a `ModelGateway` subclass registered under the `trellis.gateways` entry
     point, its name being its `LLM_GATEWAY` value. Features ask the route for a capability
     (`gateway.has(Capability.MCP)`), never for its name, so another gateway can give the same
     extras.
- MCP tools do not need any gateway: `mcp("https://host/mcp")` or `mcp(stdio(...))` (harness
  docs/tools.md). Only Code Mode is tied to the Bifrost route.
- Mention Bifrost only where a feature truly comes from it, and say "optional" there.
  `bifrost-sdk` is just the OpenAI-compatible model client used for every route that has an
  endpoint.
- The services are optional too: with none set, the harness runs everything in one process.
  Each service turns on when its setting is set. Draw optional parts dashed or label them.

## Files
Markdown, one file per Confluence page, in /home/user/trellis-confluence/ under the folder
given in your brief. File names are given in the brief. Keep each page focused: 150–600 lines.

# Coverage B: user guide pages 04.02 to 04.08

Each feature heading from the source docs, and the page that covers it. "Left out" lists
headings deliberately not documented, and why.

Pages: `04-user-guide/04.02-react-agent.md`, `04.03-tools-and-mcp.md`,
`04.04-approvals-and-questions.md`, `04.05-memory.md`, `04.06-runs-schedules-workers.md`,
`04.07-data-and-files.md`, `04.08-subagents-and-a2a.md`.

## agent-harness `docs/frameworks/react.md`

| Heading | Page |
|---|---|
| (intro, signature, the four tiers of arguments) | 04.02 How to use it, Options and settings |
| The base | 04.02 Why you need it |
| The middleware (Deep Agents', the harness's, yours opt-in) | 04.02 How it works: The middleware, one by one; Your own middleware |
| middleware() on your own graph | 04.02 Way 2 |
| Tool choice | 04.02 Good to know; 04.03 Helping the model pick |
| When a request does not fit | 04.02 When a request does not fit |
| What else is automatic | 04.02 How it works; 04.05 Push and Pull |
| Approvals, streaming, durable runs, surfaces, evaluation | 04.02 A run that pauses; 04.04; 04.06 |
| Sub-agents and child runs | 04.02 Sub-agents; 04.08 |
| Where sandbox, skills and hooks go | 04.02 Deep Agents features; 04.03 Skills; 04.04 Hooks |
| Limits | 04.02 Good to know |
| Run it | 04.02 Source in the code |

## agent-harness `docs/tools.md`

| Heading | Page |
|---|---|
| The toolbox | 04.03 What it is, How it works, Options |
| A server that asks: MCP elicitation | 04.03 MCP servers: no gateway needed |
| A server's resources: MCP resources | 04.03 MCP servers; 04.07 query_result |
| Tool choice: what helps the model pick the right tool | 04.03 Helping the model pick |
| Tool chains | 04.03 Helping the model pick |
| Every call | 04.03 How it works, Good to know |
| Large results | 04.07 Large results |
| Counting, summing, ranking over a large result | 04.07 Exact numbers, query_result |
| A query's result as a file | 04.07 A query's result as a file |
| Files kept for the user, read back | 04.07 Reading earlier files |
| Values that change: freshness | 04.03 Values that change |
| The run's tool set | 04.03 Framework tools |
| Tool hints: what the model is offered | 04.03 How it works; 04.05 memory tools |
| Code Mode | 04.03 Extras from a gateway route (Bifrost route only) |
| A framework's own tools | 04.03 Framework tools |
| Inside a run | 04.03 OpenAPI, sandbox and calls inside a run |

## agent-harness `docs/skills.md`

| Heading | Page |
|---|---|
| Skill sources | 04.03 Skills |
| Where it goes, per engine | 04.03 Skills |
| Per run | 04.03 Skills |
| Native or ours | 04.03 Skills (framework's own config stays) |
| Learned skills | 04.03 Skills |

## agent-harness `docs/prompts.md`

| Heading | Page |
|---|---|
| What, When | 04.03 Stored prompts (Bifrost route only) |
| Native or ours | 04.03 Stored prompts |
| On failure | 04.03 Good to know |
| Example | 04.03 Source in the code |

## agent-harness `docs/gateway.md` (tools part only)

| Heading | Page |
|---|---|
| What the gateway never does for a run | 04.03 Extras from a gateway route |
| Prompts | 04.03 Stored prompts |
| Who a call is for | 04.03 MCP tools from a gateway route |
| Frameworks' own MCP clients | 04.03 Extras from a gateway route |
| Reaching the gateway | 04.03 Good to know (admin auth) |
| Whose run a model call is, and its trace | not here: model calls and traces (04.13, 04.11) |

## agent-harness `docs/governance.md` and `docs/blocks/governance.md`

| Heading | Page |
|---|---|
| How a call is decided | 04.04 How it works |
| One place for approval rules | 04.04 Governance: rules in the catalog |
| The catalog, kept fresh | 04.04 Options, Good to know |
| Way 1: inside `h.wrap` | 04.04 Way 1 |
| Install and set up, The API, `governed` | 04.04 Way 2 |
| Where your framework asks | 04.04 Way 2 |
| Behaviour, With Way 1 | 04.04 Good to know |

## agent-harness `docs/interrupts.md`

| Heading | Page |
|---|---|
| Asking (incl. `ask_user`) | 04.04 Asking a person |
| Who reviews, on which screen: a `before_tool` hook | 04.04 Hooks |
| Comments, and approving for the rest of the run | 04.04 Approving |
| Results from outside: `ask` in the tool | 04.04 Asking a person |
| Telling people | 04.04 Telling people; 04.06 Webhooks |
| An inbox of your own | 04.04 An approvals screen of your own |
| Testing: `trellis.testing.Reviewer` | 04.04 Testing |
| Answering | 04.04 Approving, Good to know (who may answer) |
| How a run continues | 04.06 Resume after a restart |
| Framework approvals | 04.04 Way 1 (resume mapping table) |

## agent-harness `docs/hooks.md`

| Heading | Page |
|---|---|
| (methods, when, where, model calls are the framework's own) | 04.04 Hooks, Options |
| Mask what the UI sees | 04.04 Hooks (`on_output`) |

## agent-harness `docs/memory.md` and `docs/blocks/memory.md`

| Heading | Page |
|---|---|
| Push | 04.05 How it works, Way 1 |
| Pull | 04.05 The memory tools |
| What is recorded | 04.05 How it works |
| Background writes: what is guaranteed | 04.05 Good to know |
| Documents | 04.05 Documents |
| Outcome and grounding | 04.05 Feedback |
| The memory model endpoint | 04.05 With and without a model |
| Install and set up, One turn, Recording tool calls, More than one turn | 04.05 Way 2 and SDK only |
| Behaviour | 04.05 Good to know |

## agent-memory-service `README.md`, `docs/USAGE.md`, `docs/guide`

| Heading | Page |
|---|---|
| README: What you get, Way 1 and Way 2 | 04.05 What it is, Way 2 |
| USAGE 2 Pick a mode | 04.05 How it works |
| USAGE 3 Writing; 4 Correcting | 04.05 Forgetting and correcting |
| USAGE 5 Reading (time travel) | 04.05 Searching by date |
| USAGE 7 Evidence; 9 Agent tools; 10 Feedback | 04.05 Way 2, memory tools, Feedback |
| USAGE 14 Through the harness | 04.05 How it works |
| guide 03 Time (two clocks, lifecycle, forgetting, relative dates) | 04.05 Forgetting, Searching by date |
| guide 04 Past conversations | 04.05 Past chats |
| guide 08 Running without an LLM, memory_restatement | 04.05 With and without a model |
| USAGE 1, 6, 8, 11, 12, 13 (tenancy, profile admin, model policy, backfills) | not here: operations and admin pages |

## agent-harness `docs/runs.md`, `docs/blocks/runs.md`, `docs/reliability.md`; agent-runs README and `docs/api.md`

| Heading | Page |
|---|---|
| (run, stream, start, cancel, RunHandle) | 04.06 run, stream and start |
| Resuming a paused run | 04.06 How it works; 04.04 Approving |
| Spending: a budget per run | 04.06 Budgets |
| Workers | 04.06 Workers |
| Continuing where a run stopped | 04.06 Resume after a restart |
| Queue order and busy conversations | 04.06 Queue order |
| Earlier turns with memory off | 04.06 Earlier turns with memory off |
| A Claude or ACP session across turns | 04.06 Earlier turns with memory off |
| Child runs at once, and the task tree | 04.06 Child runs at once |
| A run's events from anywhere | 04.06 Events from anywhere |
| Admission: agent-runs' rate limit | 04.06 Retries |
| Schedules | 04.06 Schedules |
| The inbox | 04.04 An approvals screen of your own |
| agent-runs wire | 04.06 Retries, Good to know (errors) |
| blocks/runs: A run, a pause, an answer; Workers; Schedules; Webhooks; Behaviour | 04.06 Using agent-runs alone, Webhooks |
| reliability: Tool timeouts, Model timeouts, Stalled model calls, Run time limit and deadline | 04.06 Time limits |
| reliability: Retries, Every retry layer | 04.06 Retries |
| reliability: Idempotency keys, Unknown outcomes, Crash behaviour | 04.06 Resume after a restart |
| reliability: Calls made at once | 04.06 Calls made at once |
| reliability: Cancel, Releasing on shutdown | 04.06 Cancel, Workers |
| reliability: The last good tool list | 04.03 How it works |
| reliability: Agent version | 04.06 Resume after a restart, Options |
| reliability: Every timeout; Limitations | 04.06 Time limits, Good to know |
| agent-runs: Who may answer a paused run | 04.04 Good to know |
| agent-runs: Retention, Run retention, Limits | 04.06 Good to know, Options; 04.07 Retention |

## Data and files (grep: query_result, TRELLIS_FILES_URL, download)

| Item | Page |
|---|---|
| `query_result`, engines, limits, `save_as` | 04.07 |
| `TRELLIS_FILES_URL`, file store, records | 04.07 The file store |
| download route `GET {path}/runs/{run_id}/files/{name}`, signed links | 04.07 Download links |
| sandbox `outputs/` | 04.07 Files from a sandbox |
| retention of files and artifacts | 04.07 Good to know |

## agent-harness `docs/subagents.md`, `docs/blocks/a2a.md`, `docs/surfaces.md` (calling)

| Heading | Page |
|---|---|
| What, When, Where, How | 04.08 What it is, How to use it |
| Automatic (child run, at once, pauses, re-runs, crashes, cancel, run inside a run, framework helpers) | 04.08 How it works, Each framework, Good to know |
| On failure, Limits | 04.08 Good to know |
| blocks/a2a: Install, The API, As a tool of your framework, Behaviour, With Way 1 | 04.08 Way 2: RemoteAgent |
| surfaces: Calling A2A agents | 04.08 Calling another agent |
| framework pages: Sub-agents and child runs (each framework) | 04.08 Each framework, its own way |

## Left out on purpose

| Source heading | Why |
|---|---|
| runs.md "A message to a busy conversation: mode" (`mode="steer"`, `"interrupt"`) | steering messages: background-agent work, excluded by the brief |
| any run inbox, task inbox or pause/resume of a running job | not on main (brief and `_STYLE.md`) |
| gateway.md "Whose run a model call is, and its trace" | model calls and tracing, other pages |

## Not verified, or source conflicts found

- `docs/governance.md` uses `await h.tenant()`, which does not exist on main (`Harness` has only
  a private `_tenant`). 04.04 uses `MemoryClient().bind(tenant_id=..., agent_id=...)` instead.
- `docs/runs.md` lists `agent.schedule(timeout=)`; the code's argument is `run_timeout=`. 04.06
  uses `run_timeout`.
- `docs/reliability.md` says a scheduled run's record names no time limit, while `docs/runs.md`
  and agent-runs' API say a schedule's `timeout_seconds` is copied into each fired run. 04.06 only
  says the worker holds a scheduled run to the agent's `run_timeout`.
- Model client retries: `docs/reliability.md` says a `ReAct` model client makes one attempt (the
  gateway retries); `docs/configuration.md` says the `openai-compatible` and `provider-sdk` routes
  use "the client's own retries". 04.06 says one attempt on the Bifrost route and the client's own
  retries on the other routes; worth a check by the harness team.
- No code was run; examples were copied from repo docs and examples and names checked with grep.

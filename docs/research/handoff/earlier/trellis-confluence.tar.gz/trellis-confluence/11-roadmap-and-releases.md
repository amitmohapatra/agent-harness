# Roadmap and Releases

> **In short:** Right now our focus is that everything on main works well and nothing breaks. New features come later, only when there is a real need. This page lists what is being checked now, what is parked, and where to find release notes.

**Who should read this:** everyone.

## Now: make sure main works

| Work | What it means | Status |
|---|---|---|
| Full check of main | Every framework, hard and broken inputs, long jobs, zero errors | In progress |
| Break-it round | We try hard on purpose to make the agent fail (tricky questions, bad data, huge files, crashes) and fix what breaks | Next |
| Small clean-up | Remove unused definitions from agent-contracts, and add two speed indexes to agent-runs | Next |

Nothing goes into main unless all tests pass on every framework, with no drop in accuracy or speed.

## Parked (not on main)

| Feature | Where it lives | Why parked |
|---|---|---|
| Background agents: the agent hands a long task to a helper and keeps chatting, then steers, pauses or stops it | Branch `background-agents` in agent-harness, agent-runs and agent-contracts | Not needed now. For long jobs today, use durable runs (`agent.start`); see `04-user-guide/04.06-runs-schedules-workers.md`. |
| Memory using a model for every message (like Mem0 or Hindsight) | Closed pull requests in agent-memory-service (can be reopened) | Not needed now. Today's memory works well with or without a model. |
| Public memory benchmarks (LoCoMo, LongMemEval) | Not started | Optional. They only measure; they change nothing. |

## Release notes

Each repository keeps its own `CHANGELOG.md`, newest first:

| Repository | Release notes |
|---|---|
| agent-harness | `CHANGELOG.md` |
| agent-memory-service | `CHANGELOG.md` |
| agent-runs | `CHANGELOG.md` |
| agent-contracts | `CHANGELOG.md` |
| bifrost-sdk | `CHANGELOG.md` |

Which versions work together: see `09-operations/09.2-versions-and-upgrades.md`.

## Related pages
- `08-quality-and-performance.md`
- `09-operations/09.2-versions-and-upgrades.md`

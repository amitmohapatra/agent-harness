# Coverage, section D (06 architecture, 07 end-to-end flows, 09 operations)

Each feature heading from the source docs, and the page that covers it. "Not covered" says why.

## agent-harness/docs/architecture.md

| Heading | Page |
|---|---|
| The five repositories | 06.1-big-picture.md |
| Two ways | 06.1-big-picture.md, 06.2-harness-inside.md |
| System context | 06.1-big-picture.md |
| Modules, Components | 06.2-harness-inside.md |
| The pipeline | 06.2-harness-inside.md, 07.1-one-chat-turn.md |
| The bridge | 06.2-harness-inside.md, 07.1-one-chat-turn.md |
| Tools and governance | 06.2-harness-inside.md, 07.2-approval-flow.md |
| The journal and the runtime | 06.2-harness-inside.md, 07.2-approval-flow.md, 07.3-long-job-and-restart.md |
| The adapters | 06.2-harness-inside.md |
| The middleware | 06.2-harness-inside.md |
| Run states | 06.2-harness-inside.md, 06.4-runs-service.md |
| Background writes | 06.2-harness-inside.md, 07.1-one-chat-turn.md |
| Evaluation | 06.2-harness-inside.md (short) |
| Telemetry | 06.2-harness-inside.md, 09.1-running-in-production.md |

## agent-harness/docs/flows.md

| Heading | Page |
|---|---|
| A run | 07.1-one-chat-turn.md |
| Memory: push, pull, record | 07.1-one-chat-turn.md, 07.5-memory-write-and-recall.md |
| A pause, an approval and a resume (in place; by journal replay) | 07.2-approval-flow.md |
| A worker claims a run, crashes, and another resumes it | 07.3-long-job-and-restart.md |
| A schedule fires | 06.4-runs-service.md |
| A gateway MCP call, and Code Mode | 06.1-big-picture.md, 06.2-harness-inside.md (route capabilities; Bifrost route only) |
| Sub-agents | 06.2-harness-inside.md (short) |
| AG-UI chat | 07.1-one-chat-turn.md, 06.2-harness-inside.md |
| A2A | 06.2-harness-inside.md (surfaces table only) |
| Evaluation, offline and online | 06.2-harness-inside.md (short) |
| ReAct: one model step through the middleware | 06.2-harness-inside.md (middleware stack) |
| Stopping a worker | 07.3-long-job-and-restart.md |

## agent-harness/docs/reliability.md

| Heading | Page |
|---|---|
| Tool timeouts, Model timeouts, Stalled model calls | 07.1-one-chat-turn.md (failures), 09.1-running-in-production.md (runbook) |
| Run time limit and deadline | 07.3-long-job-and-restart.md, 06.4-runs-service.md |
| Retries, Every retry layer | 07.1-one-chat-turn.md, 07.3-long-job-and-restart.md |
| Idempotency keys | 07.3-long-job-and-restart.md |
| Unknown outcomes, Crash behaviour end to end | 07.3-long-job-and-restart.md, 07.2-approval-flow.md |
| Calls made at once | 06.2-harness-inside.md (journal) |
| Cancel, Releasing on shutdown | 06.4-runs-service.md, 07.3-long-job-and-restart.md |
| The last good tool list | 06.2-harness-inside.md (toolbox) |
| Agent version | 07.3-long-job-and-restart.md, 09.2-versions-and-upgrades.md |
| Every timeout, Limitations | 07.3-long-job-and-restart.md, 09.1-running-in-production.md |

## agent-harness/docs/observability.md

| Heading | Page |
|---|---|
| Spans, Trace attributes, Counters, Logs, Export, Scores | 09.1-running-in-production.md, 06.2-harness-inside.md |
| Redaction | 06.6-security-and-tenants.md |
| Events | 07.1-one-chat-turn.md |

## agent-harness/docs/versioning.md, ADR 0004, configuration.md

| Heading | Page |
|---|---|
| Compatibility (0.7.0 tables), Agent programs, When the installed version is outside the range, How to upgrade, Releases | 09.2-versions-and-upgrades.md |
| Model routes (ADR 0004, "Where a model name goes") | 06.1-big-picture.md, 06.2-harness-inside.md |
| Settings and the environment, What is on and how to turn it off | 06.1-big-picture.md, 06.2-harness-inside.md |

## agent-memory-service/docs/ARCHITECTURE.md

| Heading | Page |
|---|---|
| Shape, In the platform, Inside the service, Layers | 06.3-memory-service.md, 06.1-big-picture.md |
| Data placement, Core data model | 06.3-memory-service.md (storage), 06.6-security-and-tenants.md |
| Durability protocol | 06.3-memory-service.md (write path) |
| Retrieval pipeline | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| Memory lifecycle | 06.3-memory-service.md |
| Learning (background) | 06.3-memory-service.md (worker; feedback, grounding and tool memory) |
| Generative model access | 06.3-memory-service.md (with and without a model) |
| Caching | 06.3-memory-service.md |
| Runtime: overload, readiness, workers | 09.1-running-in-production.md |
| Observability | 09.1-running-in-production.md |

## agent-memory-service/docs/flows.md

| Heading | Page |
|---|---|
| 1. Ingest: history add | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| 2. Context build | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| 3. Search and recall | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| 4. Feedback and the review queue | 06.3-memory-service.md |
| 5. Verify and grounding | 06.3-memory-service.md, 07.1-one-chat-turn.md |
| 6. Tool catalog and hints (learned skills) | 06.3-memory-service.md |
| 7. Compaction and background jobs | 06.3-memory-service.md (the worker) |

## agent-memory-service/docs/adr (used)

| ADR | Page |
|---|---|
| 0004 transactional outbox | 06.3-memory-service.md |
| 0005 / 0021 authorization, tenants, keys, workspaces | 06.6-security-and-tenants.md |
| 0009 / 0035 consolidation, same-subject matching | 06.3-memory-service.md |
| 0013 multi-agent semantics (conflicts, RUN audience) | 06.3-memory-service.md, 06.6-security-and-tenants.md |
| 0024 (temporal), 0026 ranking | 06.3-memory-service.md |
| 0028 feedback review | 06.3-memory-service.md |
| 0036 a user's words follow the user | 06.3-memory-service.md, 06.6-security-and-tenants.md, 07.5-memory-write-and-recall.md |
| 0037 statement labeller | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| 0038 replacement across conversations | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| 0042 any model endpoint, memory follows the harness | 06.3-memory-service.md |
| 0044 earlier chats recalled | 06.3-memory-service.md, 07.5-memory-write-and-recall.md |
| others (0001 to 0003, 0006 to 0008, 0010 to 0012, 0014 to 0020, 0022, 0023, 0025, 0027, 0029 to 0034, 0039 to 0041, 0043) | not covered one by one: their effects are summarised where relevant; they are memory-section material |

## agent-memory-service deploy and operations

| Heading | Page |
|---|---|
| deploy/database.md: One connection budget per pod, Adding it up, PgBouncer in transaction mode | 09.1-running-in-production.md |
| deploy/database.md: Online migrations, Upgrading a store an earlier build wrote | 09.2-versions-and-upgrades.md |
| deploy/search.md: Layout, tenant index, payloads in RAM, applying a new layout | 09.1-running-in-production.md (scaling, disk) |
| guide/11-operations.md: compose stack, production changes, configuration, hardware, workers and periodic jobs, migrations and reindexing, observability, runbook | 09.1-running-in-production.md, 06.3-memory-service.md, 09.2-versions-and-upgrades.md |
| docs/versioning.md | 09.2-versions-and-upgrades.md |

## agent-runs/docs/ARCHITECTURE.md, README.md, api.md, configuration.md

| Heading | Page |
|---|---|
| Among the five Trellis repos, Components | 06.4-runs-service.md, 06.1-big-picture.md |
| The run lifecycle | 06.4-runs-service.md |
| Start, interrupt, resume | 06.4-runs-service.md, 07.2-approval-flow.md |
| Claim, lease and heartbeat | 06.4-runs-service.md, 07.3-long-job-and-restart.md |
| Pause and resume, and the answer check | 06.4-runs-service.md, 07.2-approval-flow.md |
| Cancel and release | 06.4-runs-service.md, 07.3-long-job-and-restart.md |
| A scheduled run firing | 06.4-runs-service.md |
| Webhook delivery and dead letters | 06.4-runs-service.md, 06.6-security-and-tenants.md |
| Run events and the SSE stream | 06.4-runs-service.md |
| The ticker | 06.4-runs-service.md |
| The tables, Code map | 06.4-runs-service.md (tables listed in the components diagram; full ER diagram not repeated) |
| README: When to use what, Who may answer a paused run | 06.4-runs-service.md, 06.6-security-and-tenants.md |
| api.md: Errors, Limits, Authentication, Runs, Artifacts, Retention, Schedules, Webhooks, Ops | 06.4-runs-service.md, 06.6-security-and-tenants.md, 09.1-running-in-production.md |
| configuration.md: every `RUNS__*` setting | 06.4-runs-service.md, 09.1-running-in-production.md |
| versioning.md | 09.2-versions-and-upgrades.md |
| The run inbox (messages to a running run: `RunMessage`, `PAUSE`) | not covered: not served by agent-runs on main (checked with grep: no route, no store). The list of paused runs (`GET /v1/runs?status=PAUSED&assignee=`, `h.inbox`) is on main and is covered |

## agent-contracts and bifrost-sdk

| Heading | Page |
|---|---|
| contracts ARCHITECTURE: In the platform, Inside the package, The ports, A run's lifecycle, The records across a run, What a pause carries, The one scope rule, The records, Errors, Wire conventions | 06.5-contracts-and-bifrost-sdk.md |
| contracts versioning | 09.2-versions-and-upgrades.md |
| bifrost-sdk ARCHITECTURE: Among the five repos, Where it sits, Inside the package, A chat completion, deny-all MCP scope, MCP tools, Errors, Retry policy, Circuit breaker, Design decisions | 06.5-contracts-and-bifrost-sdk.md |
| bifrost-sdk Virtual MCPs, stored prompts and skills, Admin | 06.5-contracts-and-bifrost-sdk.md (named as Bifrost-only extras, not detailed) |
| bifrost-sdk configuration, versioning | 06.5-contracts-and-bifrost-sdk.md, 09.2-versions-and-upgrades.md |

## Things the sources disagree on (code followed)

- Harness `reliability.md` says a scheduled run's record names no time limit; `agent.py`
  (`schedule`) and `runs.md` send `timeout_seconds`, and agent-runs copies it into each fired
  run. Pages follow the code.
- Harness `architecture.md` says the harness never writes `PARTIAL`; `pipeline.py` (`_partial`)
  records `PARTIAL` with `BUDGET_EXCEEDED`. Pages follow the code.
- Version tables: memory `versioning.md` names schema head `0031` (code: `0033`); agent-runs
  docs name head `9d5e0f1a2b3c` and 19 revisions (code: `0a6b1c2d3e4f`, 20); several pages list
  `trellis-harness` 0.4.0 (code: 0.7.0); the harness doc says `trellis-memory>=0.6.0` (code:
  `>=0.6.2`). 09.2 uses `pyproject.toml` values.
- contracts `ARCHITECTURE.md` says the memory service imports nothing from contracts; the
  memory service now vendors it for `Endpoint`. 06.5 says so.
- Harness README names `LANGFUSE_HOST`; `configuration.md` says it is retired for
  `LANGFUSE_BASE_URL`. Pages use `LANGFUSE_BASE_URL`.
- memory `guide/10-architecture.md` calls the outbox sweep `system.outbox_sweep`; the registry
  names it `periodic.outbox_sweep`. Pages use the registry name.

## Not verified by running

- No service was started; flows and diagrams were checked against the code by reading, and
  every mermaid block was parsed with mermaid 11.4.1 (31 diagrams, 0 errors).
- The example in 07.5 (a `manager` change) assumes a rule reads that slot from the sentence;
  the page says "where they can".

# Trellis glossary

> **In short:** every word you will meet in the Trellis pages, explained in one or two simple
> lines. The list is in alphabetical order. When a page uses a word you do not know, look here.

**Who should read this:** everyone, especially readers new to AI agents.

## What it is

A short dictionary of Trellis words. Most entries are plain-language. Where a term is also a
name in the code, the code name is shown in `backticks` so developers can search for it.

## Why you need it

Agent platforms use many new words, and some common words (like "run" or "memory") have a
specific meaning here. A support manager reading about "a run paused for approval in the inbox"
should know exactly what that means without asking an engineer.

## The terms, A to Z

**A2A (Agent2Agent).** An open protocol for one agent to call another agent over HTTP, even if
they are built by different teams or vendors. In Trellis, `agent.serve_a2a(app, url)` serves
your agent this way and `a2a(url)` calls a remote one.

**ACP (Agent Client Protocol).** The protocol Trellis uses to drive Kimi Code. Kimi Code's own
tools and sub-agents run inside it, and their permission requests are governed by Trellis.

**Adapter.** The small piece inside the harness that knows how to run one framework (LangGraph,
OpenAI Agents SDK, Claude Agent SDK, and so on). The harness picks the adapter from the type of
object you wrap.

**Admin key.** A key the memory service issues to a tenant's administrator. It manages keys
and workspaces and reviews feedback. Never give it to an agent.

**Agent.** A program that uses a language model to decide its next step: answer, call a tool,
or ask a person. In the code, `Agent` is also what `h.wrap(...)` returns.

**Agent card.** The small JSON document an A2A agent publishes at
`/.well-known/agent-card.json`: its name, what it does and how to call it.

**agent-runs.** The Trellis service that keeps run records, the work queue, the inbox of paused
runs, schedules and webhooks. It never runs an agent itself.

**AG-UI.** An open protocol for streaming an agent's events (text, tool calls, questions) to a
chat user interface. `agent.serve_chat(app)` serves it.

**Announce.** One of the 3 governance outcomes: the tool call runs, and an event says it ran,
so whoever watches can see it. Used for writes nobody needs to be asked about: the harness's
own schedule, memory and sandbox tools, a framework's own tools under its own permission flow,
a call an `approve_when` rule lets through, or one a person allowed earlier.

**Approval.** A pause where a person must say yes, no or "yes with changes" before a tool call
runs. In code the answer is `approve`, `reject` or `edit`.

**`approve_when`.** A rule an administrator stores in the tool catalog, like `amount > 100`.
When it is true for a call, the call asks a person. No code change is needed.

**Artifact.** Something too large to sit inside a question or a checkpoint (a big table, a
diff, a large journal). agent-runs stores it separately and the question points to it.

**Assignee.** Who should answer a paused run: `user:priya`, `role:finance`, or nobody (anyone
may answer). The inbox is filtered by it.

**Bifrost gateway (optional).** One open-source model gateway Trellis has a built-in route for
(`LLM_GATEWAY=bifrost`). Trellis does not need it. On that route you also get the gateway's
extras: its MCP tools, Code Mode, stored prompts, skills, dollar budgets and fallbacks.

**bifrost-sdk.** The OpenAI-compatible model client (`bifrost_sdk`); it also knows the Bifrost
gateway's extras. Every route with an endpoint uses it, whatever gateway or provider is behind
the endpoint.

**Block.** One Trellis piece you can use on its own in your own code: memory, runs,
governance, evaluation, the A2A client, the sandbox. Using blocks is "Way 2".

**Budget.** The most one run may spend: tokens, US dollars and tool calls (`Budget(...)`). A
dollar cap needs a route that reports each call's cost (the built-in Bifrost route does);
tokens and tool calls are counted on every route. At the limit the run ends `PARTIAL` with the
error `BUDGET_EXCEEDED`.

**Bundle.** The context the memory service returned for one question. Its `bundle_id` is what
an answer is later checked against for grounding.

**Catalog (tool catalog).** The list of tools the memory service keeps per tenant, with each
tool's risk and `approve_when` rules. Governance reads it.

**Checkpoint.** Saved state a run continues from after a pause or a crash. In Way 1 the
harness's journal is the checkpoint. In Way 2 it is your framework's own state.

**Checkpointer.** LangGraph's own way to save a graph's state between steps (for example
`InMemorySaver`).

**Child run.** The run of a sub-agent. It inherits the parent's tenant, user, thread, time
limit and trace. Its questions pause the parent.

**Citation.** Where a tool's result came from: a name, a date and a link (`Citation(...)`). It is
kept with the call's record, not shown to the model.

**Claude Agent SDK.** Anthropic's SDK that runs the Claude Code CLI as an agent. Trellis wraps
its `ClaudeAgentOptions`.

**Code Mode (Bifrost route only).** A feature of the optional Bifrost gateway where the model writes one small script that calls many tools,
instead of calling them one by one. Trellis records each call inside the script from the
gateway's log.

**Concurrency key.** A label that makes runs sharing it run one at a time, for example one
conversation or one customer account. Default: the run's conversation.

**Contracts.** The shared record types in `trellis.contracts`: `RunStart`, `RunRecord`,
`Interrupt`, `InterruptResolution`, `ToolCall` and more. No settings and no network.

**Conversation key.** The internal key for "this user's thread in this tenant". Two users
using the same thread name never share a conversation.

**Deadline.** A clock time a run must end by. Time spent queued or waiting for a person counts.
Past it the run ends `TIMEOUT`.

**Deep Agents.** A LangChain library (`create_deep_agent`) for agents with planning, files and
sub-agents. `ReAct` uses it when you ask for one of its features.

**Development key.** The memory service's local key, `dev-key`. It acts in the tenant `default`
and is refused in `staging` and `prod`.

**Elicitation (MCP).** When an MCP server asks the person a question in the middle of a tool
call. Trellis pauses the run and sends the answer back.

**Escalation.** If nobody answers a question by its deadline, agent-runs hands it to the
`escalate_to` person or group once, or ends the run `TIMEOUT`.

**Evaluation.** Scoring answers. Offline: run a test set with `h.evaluate(...)`. Online: judge a
sample of live runs with `judges=[...]`.

**Evidence status.** What the memory service says about its context: `COMPLETE`, `INCOMPLETE` or
`INSUFFICIENT`. `INSUFFICIENT` means the agent should say it does not know.

**Feedback.** A verdict on a run, a tool call or a memory. The run's own ending is `system`
feedback. A person's verdict (`confirm`, `reject`, `correct`) waits for the tenant
administrator's review.

**Framework.** The library your agent is built with: LangGraph or LangChain, Deep Agents, OpenAI
Agents SDK, Claude Agent SDK, Kimi Code. A plain function or `ReAct` also counts as a target.

**`framework_options`.** The framework's own run options (for example LangGraph's
`recursion_limit`), passed through unchanged by `h.wrap` or `agent.run`.

**Frontend tool.** A tool the chat UI offers through AG-UI. The model calls it, the app runs it,
and the result comes back to the run.

**Governance.** The check on every tool call: run it, run and announce it, or ask a person.
It uses the tool's side effect and the catalog's rules, and fails closed.

**Grounding.** Checking an answer, claim by claim, against the memory context it was given. A
fixed tenth of runs that had a context is checked automatically.

**Handoff.** In the OpenAI Agents SDK, one agent passing the conversation to another agent.
Trellis governs the tools of every agent reachable through handoffs.

**Harness.** The part of Trellis that runs your agent (`Harness`, `h.wrap`). It connects to the
services and adds every platform feature around each run.

**Hooks.** Your own code around runs and tool calls (`Hooks`): deny a call, rewrite its
arguments, ask a person, mask what the UI shows, or audit.

**Idempotency key.** A key sent with a write so that, if it is retried, the effect happens once.
Each tool call gets one that stays the same across attempts.

**Inbox.** The list of paused runs waiting for a person, filtered by assignee. `h.inbox(...)`
or `RunsClient.iterate(status=PAUSED, ...)`.

**Interrupt.** The record of a pause: the question, the tool call to approve, the options, who
should answer, the deadline. Answered with an `InterruptResolution`.

**Irreversible.** A tool side effect meaning "cannot be undone". Every call asks a person first.

**Job.** A queued run that a worker claimed. The worker's handler gets the `Job` with the run's
record and checkpoint.

**Journal.** The harness's log of what a run already did: tool results, answers, model
outputs. When a paused or crashed run continues, the journal is replayed so no question is
asked twice and no side effect repeats.

**Judge.** A model or a check that scores an answer, for example `llm_judge("Polite and
correct.")`. Online judges run in the background on a sample of runs.

**Kimi Code.** Moonshot AI's coding agent CLI. Trellis drives it over ACP with `kimi(...)`.

**Langfuse.** An open-source tool for traces, scores and test datasets. Trellis sends traces and
scores there when its keys are set.

**LangGraph / LangChain.** Popular Python libraries for building agents as graphs.
LangChain's `create_agent` returns a LangGraph graph.

**Lease.** A worker's time-limited hold on a run it claimed (60 seconds, renewed while it works).
If the worker dies, the lease runs out and another worker takes the run.

**`LocalRuns`.** The in-process run store used when `RUNS_URL` is not set. It keeps the last 1,000
finished runs for an hour each and loses everything on restart.

**MCP (Model Context Protocol).** An open protocol for serving tools to agents. An MCP server
offers tools. Trellis reaches any MCP server with `mcp("https://host/mcp")` or `mcp(stdio(...))`,
with no gateway. On a route with the MCP capability (the built-in Bifrost route), the tools the
gateway's key allows are added too.

**Memory.** What the memory service keeps: conversations, facts and preferences, documents, a
knowledge graph and which tools worked. "Push" puts the context in the input; "pull" gives the
model memory tools.

**Memory tools.** The tools added to every run when memory is on: `memory_search`,
`memory_remember`, `memory_update`, `memory_forget`, `profile_edit`, `tool_search`.

**Middleware.** Code that wraps each model or tool call inside a LangChain or Deep Agents graph.
`trellis.middleware()` gives your own graph the same harness behaviour `ReAct` has.

**OpenAI Agents SDK.** OpenAI's Python library for agents (`Agent`, `Runner`). Trellis wraps the
`Agent`.

**OpenTelemetry (OTel).** The open standard for traces. Trellis writes OTel GenAI spans, so any
OTel backend can show them.

**Platform key.** The memory service operator's key that creates tenants. It has no tenant of its
own, so calls made with it name a tenant.

**Priority.** A number from -1000 to 1000 on a queued run. A higher one is claimed first.

**Pull / push (memory).** Push: the harness puts the context into the agent's input before the
run. Pull: the model calls the memory tools itself.

**ReAct.** A common agent pattern: the model reasons, calls a tool, reads the result, and
repeats. In Trellis, `ReAct(...)` is a ready tool-calling agent for teams with no framework.

**Resume.** Answering a paused run so it continues: `agent.resume(interrupt_id, decision, ...)`.

**Reviewer.** The person who answered a pause. Stored with the decision for audit.

**Route (model route).** The one way every model call goes, chosen by `LLM_GATEWAY`:
`openai-compatible` (any OpenAI-compatible endpoint or gateway at `LLM_BASE_URL`),
`provider-sdk` (no endpoint: the provider's own SDK and key), `bifrost` (the optional Bifrost
gateway and its extras), or your own route registered under the `trellis.gateways` entry point.
Features ask the route for a capability (MCP tools, Code Mode, prompts, cost...), never its name.

**Run.** One execution of an agent for one user and one input, from start to its ending. It has
a status (`QUEUED`, `RUNNING`, `PAUSED`, `SUCCESS`, `PARTIAL`, `ERROR`, `TIMEOUT`, `CANCELLED`,
`REJECTED`) and a record in the run store.

**Run timeout.** The most working time a run may take, in seconds, across attempts. Time waiting
for a person or in the queue is not counted. Past it the run ends `TIMEOUT`.

**Sandbox.** An isolated container (Docker by default) where the agent's commands and files run,
away from your servers. One per run.

**Schedule.** A rule that starts a run on a cadence (a cron expression, or `hourly`, `daily`,
`weekly`, `weekdays`), on behalf of a person.

**Scope (memory).** Who a memory call is for: tenant, user, agent, run and thread. Nothing is
read across a scope's boundary.

**Service key.** The key an application holds. By default it may act for anyone in the tenant.
A key restricted with `may_act_as` acts only for the listed people.

**Side effect.** What a tool does to the world: `read` (runs), `write` (asks a person, who may
allow it for the conversation) or `irreversible` (asks a person at every call). Declared with
`@tool(side_effects=...)`. A tool that declares none asks too.

**Skill.** A packaged instruction set an agent can load when it needs it. Trellis reads skills
from a folder, Bifrost, Langfuse or your own store, and pins the version per run. "Learned
skills" are procedures the memory service learned from past runs.

**Spool.** A local folder (`TRELLIS_SPOOL_DIR`) where memory writes that could not be delivered
are kept and replayed at the next start.

**Steer.** A mode for a second message to a busy conversation: the message is given to the
running run at its next step instead of waiting.

**Stored prompt.** A prompt kept in the model gateway and referenced by name
(`stored("triage")`). It needs a route with the stored-prompts capability (the built-in Bifrost
route has it). Its version is pinned for the whole run.

**Sub-agent.** An agent another agent hands tasks to. Each call is a child run.

**Tenant.** One customer or organisation on a shared deployment. Every record belongs to one
tenant, and the key decides which.

**Thread.** A conversation, named by the caller (`thread="chat-42"`). Memory, LangGraph's
thread id and the default concurrency key all use it.

**Ticker.** agent-runs' second process. It fires schedules, enforces deadlines and time limits,
escalates questions and deletes old runs.

**Tool.** Something the agent can call: a Python function, an HTTP API, an MCP tool, another
agent. `@tool` turns a function into one.

**Tool hints.** The memory service's ranking of which tools fit the task. From 30 tools of the
run's own, the model is offered only the ones that fit (plus the memory tools and ones it
already used).

**Trace / span.** A trace is the full timeline of one run; a span is one step in it (a model
call, a tool call).

**Unknown outcome.** A write tool call that timed out or was cut by a crash, so nobody knows if
it took effect. Trellis tells the model so and never runs it again blindly.

**User.** The person a run is for (`user="ada"`). It is the memory scope and the default
assignee for questions.

**Virtual key (Bifrost only).** A Bifrost key that decides which models and MCP tools an agent may use and what
it may spend. Given as `LLM_API_KEY`.

**Way 1 / Way 2.** Way 1 (wrapped): the harness runs your agent. Way 2 (blocks): your framework
runs it and your code calls the pieces it wants.

**Webhook.** An HTTP call agent-runs makes to your service when a run pauses, escalates or ends,
signed so you can check it came from Trellis.

**`without=`.** The one switch that turns platform parts off for an agent or a run:
`memory`, `tool_search`, `mcp`, `code_mode`, `judges`, `grounding`.

**Worker.** A process that takes queued runs from agent-runs and runs them:
`python -m trellis.harness.worker app:h`.

**Wrap.** Attaching the harness to an agent: `agent = h.wrap(target, id="...")`. The agent itself
is not modified.

## Good to know

- A word in `backticks` is a real name in the code. Search the repositories for it.
- Some words mean different things in different tools. "Memory" in Deep Agents
  (`memory_files`) means instruction files, not the memory service.
- "Run" in Trellis is always the whole execution, not one model call.

## Related pages

- [01-home](01-home.md)
- [04.01-ways-to-use-trellis](04-user-guide/04.01-ways-to-use-trellis.md)
- [10.1-api-cheatsheet](10-reference/10.1-api-cheatsheet.md)
- [10.3-feature-checklist](10-reference/10.3-feature-checklist.md)

**Source in the code:** agent-harness `README.md`, `docs/api.md`, `docs/configuration.md`,
`docs/runs.md`, `docs/governance.md`, `docs/memory.md`; agent-contracts
`src/trellis/contracts/runs.py`; agent-runs `README.md`; agent-memory-service `README.md`,
`docs/configuration.md`.

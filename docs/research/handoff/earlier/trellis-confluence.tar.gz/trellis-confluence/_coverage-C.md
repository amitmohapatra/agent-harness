# Coverage: section C (04.09 to 04.14, 05.0 to 05.6)

Each feature heading from the source docs, and the page that covers it. Sources are the `main` clones in `/var/tmp/clean/`.

## agent-harness/docs/surfaces.md

| Heading | Page |
|---|---|
| (intro) Way 1 servers, extras `[agui]` / `[a2a]` | 04.09 (What it is, Install, Way 2) |
| AG-UI: `agent.serve_chat(...)` (routes, attachments, buffers, interrupts, front-end tools, context, state, `forwardedProps.mode`, resume decisions, reviewer, responses, OpenAPI, replicas, activity, event mapping, identity) | 04.09 |
| A2A: `agent.serve_a2a(...)` (card, task states, `metadata.mode`, resume words, CancelTask, push notifications, OpenAPI, identity) | 04.09 |
| Calling A2A agents (`a2a(url)`) | 04.09 (and 04.08) |

Left out on purpose: background-task events and task routes. Checked with grep: none on main (`background_task`, `start_async_task`, `task_inbox` have no hits in `src/`; `agui/__init__.py` has exactly 5 routes).

## agent-harness/docs/blocks/a2a.md

| Heading | Page |
|---|---|
| Install and set up, `RemoteAgent(...)` arguments | 04.09 (Options) |
| The API (`await agent(...)`, `connect`, `card`, `spec`, `InputRequired`, `reply`, errors) | 04.09 (Calling another agent, Good to know) |
| As a tool of your framework | 04.09 (summary); detail on 04.08 |
| Behaviour (identity, one thread, errors) | 04.09 (Good to know) |
| With Way 1 | 04.09 |

## agent-harness/docs/evaluation.md

| Heading | Page |
|---|---|
| Offline vs online table | 04.10 (What it is) |
| Way 1 (wrapped): automatic, and `h.evaluate` | 04.10 |
| Evaluators (`EvalCase`, `EvalScore`, built-ins) | 04.10 |
| Trajectories, tool coverage | 04.10 |
| `llm_judge` | 04.10 |
| The judge's model (alias, virtual key, cost) | 04.10 (written route-neutral: the alias is the optional Bifrost route's) |
| Offline: `evaluate` and `h.evaluate` (dataset, statuses, report) | 04.10 |
| Each run is an item of a Langfuse experiment | 04.10 (summary of attributes in Good to know) |
| Online: judges (sampling) | 04.10 |
| Langfuse setup | 04.10, 04.11 |
| Cost benchmark, The baseline measured, The gate, Tool-chain, Thread-history, Complex-questions, Load benchmark, The production path | 04.10 (one Good to know entry naming the commands); measured numbers belong to 08-quality-and-performance.md (not written by me) |

## agent-harness/docs/blocks/evaluation.md

| Heading | Page |
|---|---|
| Install and set up (`EvalServices.from_env`, variables) | 04.10 |
| Offline: `evaluate` | 04.10 (Way 2) |
| Online: `judge` | 04.10 (Way 2) |
| With your framework (LangGraph grounding, OpenAI, Claude) | 04.10 |
| With Way 1 | 04.10 |

## agent-harness/docs/api.md (`h.feedback`), memory.md (Outcome and grounding)

| Heading | Page |
|---|---|
| `h.feedback` verdicts, review, outcome precedence | 04.10 (Feedback from people), 04.11 (Scores) |

## agent-harness/docs/observability.md

| Heading | Page |
|---|---|
| Spans | 04.11 |
| Trace attributes | 04.11 |
| Counters | 04.11 |
| Logs (`JSONFormatter`) | 04.11 |
| Export (straight to Langfuse, through the collector) | 04.11 |
| Scores | 04.11 |
| Redaction | 04.11 |
| Events (spent, tool-call endings) | 04.11 |

## agent-harness/docs/sandbox.md

| Heading | Page |
|---|---|
| Engine table, `sandbox()` | 04.12 |
| What (tools, provider interface) | 04.12 |
| When | 04.12 (Why you need it) |
| Where | 04.12 |
| How (`SandboxSpec`, `DockerSandbox`, `reap`, `SandboxRef`) | 04.12 |
| The image, environment card | 04.12 |
| Files for the user: `outputs/` | 04.12 |
| Automatic (life cycle, every call is a tool call, Docker) | 04.12 |
| Way 2: without a harness | 04.12 |
| On failure | 04.12 (Good to know) |
| Native sandboxes: theirs or ours | 04.12, and 05.2 / 05.3 / 05.4 / 05.5 |
| Other providers: E2B, Daytona, Modal (design note) | 04.12 (Another provider) |
| Limits | 04.12 |
| Run it | 04.12 (Source, example) |

## agent-harness/docs/gateway.md, configuration.md (Models), gateways.py, bifrost-sdk/README.md

| Heading | Page |
|---|---|
| Where a model name goes (routes, `LLM_AUTH`, name forms, extras, per framework, doctor) | 04.13 |
| Your own route (`ModelGateway`, entry point `trellis.gateways`, `Capability`) | 04.13 (Option 4, Capabilities by route) |
| What the gateway never does for a run | 04.13 (Bifrost extras) |
| Prompts | 04.13 (Bifrost extras); in depth elsewhere |
| Who a call is for | 04.13 |
| Whose run a model call is, and its trace | 04.13 |
| Frameworks' own MCP clients | 04.13 |
| Reaching the gateway | 04.13 |
| Budgets and fallbacks in Bifrost (`network_config.max_retries`, virtual key fallbacks, `Admin`) | 04.13 |
| bifrost-sdk: Install, Quickstart, Any endpoint any login, Which method when, Configuration, Errors in short | 04.13 |
| bifrost-sdk: Start here, Where this fits, Documentation | 04.13 (Way 2 section) |
| bifrost-sdk: Development (live tests) | not covered: contributor content of the SDK repo, not user guide material |

## Troubleshooting (three repos)

| Heading | Page |
|---|---|
| harness: Errors when built or wrapped | 04.14 |
| harness: Runs | 04.14 |
| harness: Tools, governance and the gateway | 04.14 (rewritten route-neutral) |
| harness: Memory and evaluation | 04.14 |
| harness: FAQ | 04.14 (Good to know) |
| harness: On failure, feature by feature | 04.14 (pointer to feature pages) |
| memory service: status table, Writing, Reading, Authentication and keys, The service, Models, Development | 04.14 |
| agent-runs: Problem codes, Symptoms, FAQ | 04.14 |

## agent-harness/docs/matrix.md

| Heading | Page |
|---|---|
| Way 1 table (every row) | 05.0 (grouped into plain-words rows) |
| Way 2 table | 05.0 (Way 2 blocks table) |
| What the Kimi Code column does not show | 05.0, 05.5 |
| Reasons | 05.0 (Why a framework shows "No") |

## Framework pages and recipes

| Source heading | Page |
|---|---|
| docs/README.md Which target | 05.0 |
| langgraph.md: every heading (existing project, middleware(), automatic, approvals and pauses, run options, streaming, durable runs, sub-agents, AG-UI and A2A, evaluation, where sandbox/skills/hooks go, native or ours, conversations, limits, run it) | 05.1 |
| blocks/langgraph.md: Install, The tools, One run, Across processes, What you own | 05.1 (Way 2) |
| deepagents.md: every heading (existing project, what the harness sees, sub-agents, store, where things go, native or ours, approvals/streaming/durable/surfaces/evaluation, conversations, limits, run it) | 05.2 |
| Deep Agents Way 2 (uses blocks/langgraph.md; `examples/04_no_harness/deepagents_sdks.py`) | 05.2 |
| openai-agents.md: every heading | 05.3 |
| blocks/openai-agents.md: Install, The tools, One run, Across processes, What you own | 05.3 (Way 2) |
| claude-agent-sdk.md: every heading | 05.4 |
| blocks/claude-agent-sdk.md: Install, The tools and the permission callback, One run, What you own | 05.4 (Way 2) |
| kimi.md: every heading (using, automatic, approvals, native or ours, what ACP does not show, conversations, models/swarms/limits, streaming, tests) | 05.5 |
| Kimi Way 2 | 05.5 says there is no recipe on main |
| functions.md: every heading | 05.6 |
| Functions Way 2 (blocks/runs.md Workers, blocks/governance.md, `governed_tools.py`) | 05.6 |

## Not verified, or source issues found

- `agent-harness/docs/blocks/evaluation.md` says to pass `Settings.from_env().eval_sample` (`TRELLIS_EVAL_SAMPLE`). That field does not exist on main (no hit in `src/`), and `configuration.md` lists `TRELLIS_EVAL_SAMPLE` as retired. Left out of 04.10; pages use a number for `sample=`.
- The Claude page's claim that the real CLI's parallel tool calls are "unverified" is the matrix's own wording; not checked further.
- The note that a custom route needs a Bifrost-compatible gateway client for MCP, prompts, skills and the judge alias is from reading `gateways.py` and `clients/bifrost.py` (`gateway_client()` returns `trellis.harness.clients.bifrost.Gateway`); no doc states it.

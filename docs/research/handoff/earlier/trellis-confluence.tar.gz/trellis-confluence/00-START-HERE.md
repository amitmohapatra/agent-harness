# How to use these pages in Confluence

Each Markdown file here is one Confluence page. Folders are parent pages. Put the pages in the order of their numbers.

## Page tree

```
Trellis Agent Platform                     (space home = 01-home.md)
├── 01  Home                                 01-home.md
├── 02  Glossary                             02-glossary.md
├── 03  Getting Started
│   ├── 03.1 Quickstart                      03-getting-started/03.1-quickstart.md
│   ├── 03.2 Install                         03-getting-started/03.2-install.md
│   ├── 03.3 Configuration                   03-getting-started/03.3-configuration.md
│   └── 03.4 Deploy and Onboard              03-getting-started/03.4-deploy-and-onboard.md
├── 04  User Guide
│   ├── 04.01 Ways to Use Trellis            04-user-guide/04.01-ways-to-use-trellis.md
│   ├── 04.02 ReAct Agent                    04-user-guide/04.02-react-agent.md
│   ├── 04.03 Tools and MCP                  04-user-guide/04.03-tools-and-mcp.md
│   ├── 04.04 Approvals and Questions        04-user-guide/04.04-approvals-and-questions.md
│   ├── 04.05 Memory                         04-user-guide/04.05-memory.md
│   ├── 04.06 Runs, Schedules and Workers    04-user-guide/04.06-runs-schedules-workers.md
│   ├── 04.07 Data and Files                 04-user-guide/04.07-data-and-files.md
│   ├── 04.08 Sub-agents and A2A             04-user-guide/04.08-subagents-and-a2a.md
│   ├── 04.09 Chat UI and Serving            04-user-guide/04.09-chat-ui-and-serving.md
│   ├── 04.10 Evaluation                     04-user-guide/04.10-evaluation.md
│   ├── 04.11 Observability                  04-user-guide/04.11-observability.md
│   ├── 04.12 Sandbox                        04-user-guide/04.12-sandbox.md
│   ├── 04.13 Models and Gateway             04-user-guide/04.13-models-and-gateway.md
│   ├── 04.14 Troubleshooting                04-user-guide/04.14-troubleshooting.md
│   └── 04.15 Common Scenarios               04-user-guide/04.15-common-scenarios.md
├── 05  Frameworks
│   ├── 05.0 Which Framework                 05-frameworks/05.0-which-framework.md
│   ├── 05.1 LangGraph and LangChain         05-frameworks/05.1-langgraph-langchain.md
│   ├── 05.2 Deep Agents                     05-frameworks/05.2-deep-agents.md
│   ├── 05.3 OpenAI Agents SDK               05-frameworks/05.3-openai-agents.md
│   ├── 05.4 Claude Agent SDK                05-frameworks/05.4-claude-agent-sdk.md
│   ├── 05.5 Kimi Code                       05-frameworks/05.5-kimi.md
│   └── 05.6 Plain Functions                 05-frameworks/05.6-plain-functions.md
├── 06  Architecture
│   ├── 06.1 Big Picture                     06-architecture/06.1-big-picture.md
│   ├── 06.2 Inside the Harness              06-architecture/06.2-harness-inside.md
│   ├── 06.3 Memory Service                  06-architecture/06.3-memory-service.md
│   ├── 06.4 Runs Service                    06-architecture/06.4-runs-service.md
│   ├── 06.5 Contracts and Bifrost SDK       06-architecture/06.5-contracts-and-bifrost-sdk.md
│   └── 06.6 Security and Tenants            06-architecture/06.6-security-and-tenants.md
├── 07  End-to-End Flows
│   ├── 07.1 One Chat Turn                   07-end-to-end-flows/07.1-one-chat-turn.md
│   ├── 07.2 Approval Flow                   07-end-to-end-flows/07.2-approval-flow.md
│   ├── 07.3 Long Job and Restart            07-end-to-end-flows/07.3-long-job-and-restart.md
│   ├── 07.4 Data Question to File           07-end-to-end-flows/07.4-data-question-to-file.md
│   └── 07.5 Memory Write and Recall         07-end-to-end-flows/07.5-memory-write-and-recall.md
├── 08  Quality and Performance              08-quality-and-performance.md
├── 09  Operations
│   ├── 09.1 Running in Production           09-operations/09.1-running-in-production.md
│   └── 09.2 Versions and Upgrades           09-operations/09.2-versions-and-upgrades.md
├── 10  Reference
│   ├── 10.1 API Cheat Sheet                 10-reference/10.1-api-cheatsheet.md
│   ├── 10.2 Settings Reference              10-reference/10.2-settings-reference.md
│   └── 10.3 Feature Checklist               10-reference/10.3-feature-checklist.md
└── 11  Roadmap and Releases                 11-roadmap-and-releases.md
```

## Who should start where

| You are | Read in this order |
|---|---|
| Manager, product or business | 01 Home → 07 End-to-End Flows (the top part of each) → 08 Quality → 11 Roadmap |
| New developer | 01 → 03.1 Quickstart → 04.01 Ways to Use → your framework in 05 → 04 pages you need |
| Architect | 06 Architecture → 07 Flows → 09 Operations |
| Operations / SRE | 03.4 Deploy → 09 Operations → 04.14 Troubleshooting → 10.2 Settings |
| Support | 02 Glossary → 04.14 Troubleshooting → 04.15 Common Scenarios |

## Every page has the same shape

1. **In short**: 2–3 lines anyone can understand.
2. **Who should read this.**
3. **What it is / Why you need it**: plain words and a real-life example.
4. **How it works**: numbered steps, with a diagram where it helps.
5. **How to use it**: every way, with code (developers).
6. **Options and settings**: a table.
7. **Good to know**: limits, common mistakes, what happens on failure.
8. **Related pages** and **Source in the code.**

Non-developers can stop after section 4.

## Importing into Confluence

1. Create the space "Trellis Agent Platform" and use `01-home.md` as its home page.
2. For each folder, create a parent page (for example "04 User Guide") with the **Children Display** macro.
3. For each file, create a page and paste the Markdown with **Insert → Markup → Markdown**. Most Markdown converts directly.
4. Diagrams written in ```` ```mermaid ```` need a Mermaid macro (for example "Mermaid Diagrams for Confluence"). Without the macro, paste the diagram code into mermaid.live and insert the image.
5. Add the **Table of Contents** macro at the top of long pages.
6. The **Source in the code** line on each page tells you which repository file to check when you update the page.

## Keeping it up to date

The repositories are the source of truth. When a feature changes, update the repo docs first, then the matching page here (use **Source in the code** to find it).

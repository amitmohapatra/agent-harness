# Trellis home

> **In short:** Trellis is the platform that sits around an AI agent your team already built.
> It gives that agent memory of the people it works for, safe tools, a person in the loop for
> risky actions, runs that survive a restart, quality checks and tracing. Your agent code stays
> as it is.

**Who should read this:** everyone. Start here before any other Trellis page.

## What it is

An AI agent is a program that uses a language model to decide what to do next: answer a
question, look something up, or take an action through a tool. Building the agent itself is the
easy part. Running it safely for real people is the hard part.

Trellis is that second part. It is a set of 5 code repositories that work together:

- a **harness** that runs your agent and adds the platform features around every run;
- a **memory service** that remembers users, conversations, documents and which tools worked;
- a **runs service** that keeps every run on record, so a run can wait for a person for days
  and still finish;
- a small package of **shared records** (the "contracts") so every piece speaks the same language;
- a **model client** (`bifrost-sdk`): the OpenAI-compatible model client (it also knows the
  Bifrost gateway's extras). It is used for every route that has an endpoint, whatever gateway
  or provider sits behind it.

**Trellis is gateway-neutral.** Every model call of every framework goes one way, called a
**route**, chosen from the settings (`LLM_GATEWAY`):

| Route | When | What you get |
|---|---|---|
| `openai-compatible` | `LLM_BASE_URL` set (the default route then) | any OpenAI-compatible endpoint or gateway: OpenAI, OpenRouter, a LiteLLM proxy, Ollama, vLLM, llama.cpp, Anthropic's or Gemini's compatible endpoints; a Google or AWS login with `LLM_AUTH=google` or `aws`. Models only |
| `provider-sdk` | no `LLM_BASE_URL` | the model's provider through its own SDK and key (`OPENAI_API_KEY`, `ANTHROPIC_API_KEY`...). Models only |
| `bifrost` | `LLM_GATEWAY=bifrost` with `LLM_BASE_URL` | a built-in route for the optional Bifrost gateway, which also gives that gateway's extras: its MCP tools, Code Mode, stored prompts, skills, dollar budgets, fallbacks |
| your own | `LLM_GATEWAY=<name>` | a `ModelGateway` subclass a package registers under the `trellis.gateways` entry point |

A feature asks the route whether it has a capability, never which route it is, so another
gateway can give the same extras through a route of its own. Your own `@tool` tools, your own
MCP servers (`mcp(...)`) and each framework's own tools work on every route.

Your agent can be built with LangGraph or LangChain, Deep Agents, the OpenAI Agents SDK, the
Claude Agent SDK, Kimi Code, our own `ReAct` agent, or a plain Python function. Trellis does not
change or re-implement that framework.

## Why you need it

Think of a bank's support desk. The bank builds a chatbot that can check balances and refund
fees. Before it goes live, many questions come up:

- Does it remember that this customer called yesterday about the same fee?
- Who approves a refund above a limit, and what if that person answers tomorrow morning?
- If the server restarts while the refund waits for approval, is the refund lost, or done twice?
- How do we know the answers are correct and polite, week after week?
- Can we see every step the agent took when a customer complains?

Every team that ships an agent has to answer these. Trellis answers them once, for every agent
and every framework, so each team writes only its agent.

## How it works

1. **Build** the agent, with your framework or with `ReAct` when you have none.
2. **Wrap** it: `h.wrap(agent, id="...")` attaches the harness. The harness reads where each
   service is from environment variables. A service whose variable is not set is simply off.
3. **Run** it: `agent.run(...)` where you used to call the framework.
4. Around every run, the harness pushes the user's memory into the agent's input, checks every
   tool call (run it, or ask a person first: once a conversation for a write, every time for an
   irreversible action), pauses for approvals,
   records what happened, judges a sample of answers and traces it all.

```mermaid
flowchart LR
  app["Your service"] --> harness["agent-harness<br/>(trellis.harness)"]
  harness --> mem["trellis.memory SDK"] -.-> memory[("Memory service<br/>(optional: MEMORY_URL)")]
  harness --> runsdk["trellis.runs SDK"] -.-> runs[("agent-runs<br/>(optional: RUNS_URL)")]
  harness --> bf["bifrost-sdk<br/>(OpenAI-compatible model client)"]
  bf -.-> endpoint[("model endpoint or gateway<br/>(any OpenAI-compatible; optional)")]
  harness -.-> provider[("provider SDK and key<br/>(when no endpoint is set)")]
  harness --> contracts["agent-contracts<br/>(shared records)"]
```
Dashed parts are optional. The memory service and agent-runs are optional too: with neither
set, the harness keeps everything in its own process.

### The 5 repositories, in plain words

| Repository | Install name (import) | What it does, in plain words |
|---|---|---|
| agent-harness | `trellis-harness` (`trellis`, `trellis.harness`) | Runs your agent and adds memory, tool checks, approvals, durable runs, evaluation, tracing and chat or agent-to-agent serving around it. Also holds the governance, evaluation and A2A blocks. |
| agent-memory-service | `trellis-memory` (`trellis.memory`) | A service plus its Python client. It keeps conversations, facts and preferences, uploaded documents and which tools worked, and hands back the right context for each question. It also issues the API keys and keeps the tool catalog (the approval rules). |
| agent-runs | `trellis-runs` (`trellis.runs`) | A service plus its Python client. It keeps a record of every run, the queue that workers take runs from, paused runs waiting for a person (the inbox), schedules and webhooks. It never runs an agent itself. |
| agent-contracts | `trellis-contracts` (`trellis.contracts`) | The shared record types every other piece takes and returns: a run, a pause, its answer, a tool call, an event. No settings, no network, types only. |
| bifrost-sdk | `bifrost-sdk` (`bifrost_sdk`) | The OpenAI-compatible model client (it also knows the Bifrost gateway's extras). Every route with an endpoint uses it, whatever sits behind that endpoint. Against a Bifrost gateway (`gateway="bifrost"`) it can also list and run the gateway's MCP tools, read its tool-call log and stored prompts, and manage keys and budgets. |

## How to use it

There are 3 ways to use Trellis. All 3 use the same services and the same records, so one
deployment can mix them. The full comparison is in
[04.01-ways-to-use-trellis](04-user-guide/04.01-ways-to-use-trellis.md).

**Way 1, wrapped: the harness runs your agent.** You get every feature at once.

```python
from trellis import Harness, ReAct, tool


@tool(side_effects="irreversible")
def reorder(sku: str, qty: int) -> str:
    """Order more units of a SKU from the supplier.

    Args:
        sku: the SKU, like "SKU-1"
        qty: how many units to order
    """
    return f"ordered {qty} x {sku}"


h = Harness()
agent = h.wrap(
    ReAct(system_prompt="You keep stock above 10 units.", model="openai/gpt-4.1-mini", tools=[reorder]),
    id="stock-keeper",
)
result = await agent.run("Top up SKU-1.", user="ada")
```

**Way 2, pluggable blocks: your framework runs the agent, your code calls our pieces.**

```python
from trellis.memory import MemoryClient

memory = MemoryClient()  # MEMORY_URL and TRELLIS_API_KEY
scope = memory.bind(user_id="ada", thread_id="chat-42").agent("support", agent_run_id=run_id)
pushed = await scope.context(question, window=False)  # your framework keeps the history
```

**SDKs only, no harness.** `trellis.memory`, `trellis.runs`, `trellis.contracts` and
`bifrost_sdk` are separate packages. Code that needs no governance or evaluation uses only them
(see `examples/04_no_harness` in agent-harness).

### What you get out of the box

Each line links to the page that explains it.

| Capability | In one line | Page |
|---|---|---|
| A ready agent loop | `ReAct`: a tool-calling agent for teams with no framework | [04.02-react-agent](04-user-guide/04.02-react-agent.md) |
| Tools and MCP | your functions, OpenAPI services and any MCP server (`mcp(...)`, no gateway needed); a gateway's shared MCP tools need a route with that capability; Code Mode needs the Bifrost route | [04.03-tools-and-mcp](04-user-guide/04.03-tools-and-mcp.md) |
| Approvals and questions | risky calls wait for a person; the agent can ask a person a question; your own rules as hooks | [04.04-approvals-and-questions](04-user-guide/04.04-approvals-and-questions.md) |
| Memory | the agent knows the user, past conversations, documents and learned procedures | [04.05-memory](04-user-guide/04.05-memory.md) |
| Durable runs | runs that wait days for a person, workers, schedules, time limits, retries, cancel, budgets | [04.06-runs-schedules-workers](04-user-guide/04.06-runs-schedules-workers.md) |
| Data and files | large tool results read in pages or with SQL, documents, files made for the user | [04.07-data-and-files](04-user-guide/04.07-data-and-files.md) |
| Sub-agents and A2A | an agent that hands work to other agents, local or remote | [04.08-subagents-and-a2a](04-user-guide/04.08-subagents-and-a2a.md) |
| Chat UI and serving | serve the agent to a chat UI (AG-UI) or to other agents (A2A) | [04.09-chat-ui-and-serving](04-user-guide/04.09-chat-ui-and-serving.md) |
| Evaluation | score a test set before shipping, and judge live answers | [04.10-evaluation](04-user-guide/04.10-evaluation.md) |
| Observability | traces in Langfuse or any OpenTelemetry backend, secrets masked | [04.11-observability](04-user-guide/04.11-observability.md) |
| Sandbox | code the agent writes runs in a container of the run's own | [04.12-sandbox](04-user-guide/04.12-sandbox.md) |
| Models and routes | any OpenAI-compatible endpoint or gateway, a provider key, or a route of your own; skills from a folder, Langfuse or your store; stored prompts, gateway skills, fallbacks and dollar budgets on a route that has them (the built-in Bifrost route does) | [04.13-models-and-gateway](04-user-guide/04.13-models-and-gateway.md) |
| Troubleshooting | what an error means and what to do | [04.14-troubleshooting](04-user-guide/04.14-troubleshooting.md) |
| Common scenarios | "I want to do X, use Y" | [04.15-common-scenarios](04-user-guide/04.15-common-scenarios.md) |

The full list of every feature, with which framework supports it, is
[10.3-feature-checklist](10-reference/10.3-feature-checklist.md).

## Options and settings

Each thing has one place. The short version:

| Place | What goes there |
|---|---|
| the environment | where the models and each service are, and their keys: `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_GATEWAY`, `LLM_AUTH`, `MEMORY_URL`, `RUNS_URL`, `TRELLIS_API_KEY` and a few more |
| the services | Memory service: tool risk and approval rules. agent-runs: schedules. Your model gateway, if you run one (for example Bifrost): model routing, fallbacks, budgets, shared MCP tools, stored prompts |
| the builder (`ReAct` or your framework's) | the model, the instructions, the tools, the output schema, sub-agents |
| `h.wrap(...)` | every run of the agent: `hooks`, `judges`, `budget`, `run_timeout`, `without`, `framework_options` |
| `agent.run(...)` | this one run: `user`, `thread`, `run_timeout`, `deadline`, `budget`, `without`, `framework_options` |

Every setting: [03.3-configuration](03-getting-started/03.3-configuration.md) and
[10.2-settings-reference](10-reference/10.2-settings-reference.md).

## Good to know

- **Nothing set means everything local.** With no environment variable set, the harness runs
  in one process: no memory, runs kept in memory, the tenant `default`. This is good for a first
  try and for tests. Nothing survives a restart.
- **Not on PyPI yet.** Install from source, with the 5 repositories side by side
  ([03.2-install](03-getting-started/03.2-install.md)).
- **One key for both services.** The memory service issues the Trellis key. agent-runs asks the
  memory service who a key belongs to, so it needs no onboarding of its own.
- **Your framework is not changed.** The harness detects the framework from the object you wrap
  and runs it with the framework's own calls.

### Where to start

| You are | Start with |
|---|---|
| new to Trellis, any role | this page, then [02-glossary](02-glossary.md) |
| a developer trying it today | [03.1-quickstart](03-getting-started/03.1-quickstart.md) (no services needed) |
| choosing how to adopt it | [04.01-ways-to-use-trellis](04-user-guide/04.01-ways-to-use-trellis.md), then [05.0-which-framework](05-frameworks/05.0-which-framework.md) |
| setting up a real deployment | [03.4-deploy-and-onboard](03-getting-started/03.4-deploy-and-onboard.md) |
| looking for one feature | [04.15-common-scenarios](04-user-guide/04.15-common-scenarios.md) or [10.3-feature-checklist](10-reference/10.3-feature-checklist.md) |

## Related pages

- [02-glossary](02-glossary.md)
- [03.1-quickstart](03-getting-started/03.1-quickstart.md)
- [03.2-install](03-getting-started/03.2-install.md)
- [03.3-configuration](03-getting-started/03.3-configuration.md)
- [03.4-deploy-and-onboard](03-getting-started/03.4-deploy-and-onboard.md)
- [04.01-ways-to-use-trellis](04-user-guide/04.01-ways-to-use-trellis.md)
- [10.1-api-cheatsheet](10-reference/10.1-api-cheatsheet.md)
- [05.0-which-framework](05-frameworks/05.0-which-framework.md), [06.1-big-picture](06-architecture/06.1-big-picture.md), [07.1-one-chat-turn](07-end-to-end-flows/07.1-one-chat-turn.md) and the other 07.x flows

**Source in the code:** agent-harness `README.md`, `docs/README.md`, `docs/architecture.md`;
agent-memory-service `README.md`; agent-runs `README.md`; agent-contracts `README.md`;
bifrost-sdk `README.md`.

# Quality and Performance

> **In short:** We test every framework Trellis supports with the same 137 questions and score each answer strictly. Our own ReAct agent gets 136 of 137 right, ties for the top score, and is the cheapest. Idle chats cost almost nothing, and you handle more jobs by adding workers.

**Who should read this:** everyone who wants to know how good, how fast and how costly Trellis is.

## What we measure

| What | What it means |
|---|---|
| Strict accuracy | The answer must be exactly right (numbers, names, dates). Partly right counts as wrong. |
| Held-out accuracy | Questions the team never looked at while improving the system, to catch "teaching to the test". |
| Seconds per turn | How long the user waits for one answer. |
| Cost per run | Model cost for the whole 137-question test, in US dollars. |
| Model calls per question | How many times the agent called the model to answer one question. |

All numbers below use the same small model (Claude Haiku), with memory switched on, on the same 137 questions.

## Accuracy, speed and cost by framework

| Framework (adapter) | Strict accuracy | Seconds per turn | Cost per full test run |
|---|---|---|---|
| **ReAct (ours)** | **136 / 137 (99%)** | 5.0 | **$0.14** |
| OpenAI Agents SDK | 136 / 137 | 4.8 | $0.34 |
| Trellis middleware on your own `create_agent` | 136 / 137 | 4.3 | $0.31 |
| Deep Agents | 136 / 137 | 4.5 | $0.46 |
| LangGraph | 135 / 137 | 6.6 | $0.34 |
| Claude Agent SDK | 130 / 137 | 8.1 | $0.44 |
| Kimi Code | 129 / 137 | 9.5 | $0.73 |

ReAct is the cheapest because it uses prompt caching well: on repeated parts of the prompt, about 60% of the cost is saved without losing accuracy.

*Last measured: 2 November 2026. A fresh check on the current main is in progress; this page will be updated with its numbers.*

## Accuracy by type of question

The 137 questions cover 10 types, so no single type can hide a weakness.

| Question type | Example | ReAct |
|---|---|---|
| Past chats | "What reorder number did you give me on Monday?" | 30 / 30 |
| Analytics and calculation | "What was the average order value last quarter?" | 18 / 18 |
| Explanation | "Why did sales drop in March?" | 21 / 21 |
| What-if | "What if we raise the price by 10%?" | 11 / 11 |
| Recommendation | "Which supplier should we use?" | 1 / 1 |
| Follow-up | "And for the cotton one?" | 34 / 34 |
| Clarify | The question is unclear, so the agent must ask back | 4–5 / 5 |
| Abstain | The answer is not known, so the agent must say so | 4 / 4 |
| Files and data | Read a file or make a downloadable file | 5–6 / 6 |
| Tool chains | Several tools one after another | 7 / 7 |

## Does memory help?

Yes, a lot. Same test, ReAct, memory on versus off:

| | Memory on | Memory off |
|---|---|---|
| Strict accuracy | 136 / 137 | 115 / 137 |
| Past-chat questions | 30 / 30 | 10 / 30 |
| Follow-up questions | 34 / 34 | 34 / 34 |

Without memory the agent cannot answer "what did I tell you last week". Follow-ups inside the same chat work either way.

## Memory on its own

The memory service is also tested without any model (rules only): 0.96, 0.995 and 0.99 on its three capability tests (facts, updates, recall).

## Scale and load

Tested with a fake model on a 4-core machine, 2 minutes per step, with zero errors in every step.

| Test | Result |
|---|---|
| 1,000 to 100,000 open chats with nothing running | About 0.1 database queries a second and 0.2–0.3% CPU. A chat is only rows in the database; nothing runs for it while it is idle. |
| 100 durable runs at once | About 465 database queries a second. |
| 500 durable runs at once | About 800 database queries a second. The worker's CPU is the limit; adding a worker adds capacity. |
| 500 people checking status at the same time | Slow on one API process (about 6 s for the slowest 5% of replies). Spreading users over 4 API processes brought it under 1 s. |

Note: two database indexes that make "list one user's runs" and "list one conversation's runs" fast at 100,000+ runs (2.3 ms to 0.19 ms, and 9.5 ms to 0.15 ms) are ready but not yet on main.

**What this means for you:**
- More users, more API processes. More jobs, more workers.
- The database connection pool (20 per agent-runs process) and agent-runs' per-tenant rate limit (3,000 requests a minute by default) are the settings to raise for heavy use.

## How we keep quality from going down

Every change to the code must follow these rules before it can go into main:

1. A test that fails first, then the fix.
2. All tests pass on Python 3.12 and 3.13, for every framework.
3. No drop in accuracy on any question type, and no rise in time per answer, beyond normal run-to-run variation (we run twice to see this variation).
4. Every failure is checked: is it the model, the framework, or our code? Ours is always fixed.

## Related pages
- `05-frameworks/05.0-which-framework.md`
- `04-user-guide/04.05-memory.md`
- `09-operations/09.1-running-in-production.md`

**Source:** the validation runs of 1–2 November 2026 (137 strict questions, Claude Haiku), the memory capability tests, and the 2 November load test (the plain durable-run figures, which are what main uses).

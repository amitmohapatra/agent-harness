# Coverage, section A (home, glossary, getting started, ways to use, scenarios, reference)

Each feature heading from the source docs (main branches in /var/tmp/clean/), and the page that
covers it. Pages: 01-home, 02-glossary, 03.1 to 03.4, 04.01, 04.15, 10.1 to 10.3.

## agent-harness README.md

| Source heading | Covered in |
|---|---|
| Start here (build, wrap, run walkthrough) | 03.1-quickstart |
| Where things go | 03.3-configuration, 01-home |
| Any provider: an endpoint, Bifrost, or a provider key | 03.3-configuration (routes), 01-home, 02-glossary (Route) |
| What do I need? | 04.15-common-scenarios, 10.3-feature-checklist |
| Two ways to use Trellis | 04.01-ways-to-use-trellis, 01-home |
| The five repositories | 01-home |
| Install | 03.2-install |
| Configuration | 03.3-configuration |
| Documentation | 01-home (where to start) |
| Development (`make` targets) | 03.1-quickstart (`make install`, `make examples`, `make examples-live`), 03.2-install |

## agent-harness docs/README.md

| Source heading | Covered in |
|---|---|
| Reference | 10.1-api-cheatsheet, 03.3-configuration |
| Way 1: wrapped | 04.01-ways-to-use-trellis |
| Which target | 04.01-ways-to-use-trellis, 04.15-common-scenarios |
| Way 2: pluggable blocks | 04.01-ways-to-use-trellis |
| Recipes (LangGraph, OpenAI Agents, Claude) | 04.01-ways-to-use-trellis (pointer) |
| Composition: a Harness is the blocks you give it | 04.01-ways-to-use-trellis |

## agent-harness docs/configuration.md and .env.example

| Source heading | Covered in |
|---|---|
| Where each thing goes | 03.3-configuration |
| Settings and the environment | 03.3-configuration, 10.2-settings-reference |
| Models / Where a model name goes | 03.3-configuration, 01-home |
| `LLM_AUTH` strategies | 03.3-configuration, 10.2-settings-reference |
| Retired variables | 03.3-configuration, 10.2-settings-reference |
| A working local setup / the same in code | 03.3-configuration, 03.1-quickstart |
| What is automatic | 03.3-configuration, 10.3-feature-checklist |
| What is on, and how to turn it off (`without=`) | 03.3-configuration |
| The framework's own run options (`framework_options=`) | 03.3-configuration |
| What code passes | 03.3-configuration, 10.1-api-cheatsheet |
| Who the deployment is (tenant, writes, memory model endpoint) | 03.3-configuration, 03.4-deploy-and-onboard |
| What is not a setting | 03.3-configuration |
| `trellis doctor` | 03.3-configuration, 10.1-api-cheatsheet |

## agent-harness docs/api.md

| Source heading | Covered in |
|---|---|
| Harness | 10.1-api-cheatsheet |
| h.wrap, h.prompt, h.memory_tools, h.worker | 10.1-api-cheatsheet |
| h.inbox, h.feedback, h.add_document, h.conversation, h.evaluate | 10.1-api-cheatsheet |
| Agent: run, stream, start, resume, execute, cancel, events, schedule, serve_chat, serve_a2a | 10.1-api-cheatsheet |
| RunHandle, Result, Citation, Runtime | 10.1-api-cheatsheet |
| ReAct, middleware, Budget | 10.1-api-cheatsheet |
| Tools: tool, mcp, stdio, a2a, ask_user, openapi, sandbox, kimi, deep_agent, skills, stored, llm_judge | 10.1-api-cheatsheet |
| Hooks, current, Settings | 10.1-api-cheatsheet |
| The blocks (Way 2) | 10.1-api-cheatsheet, 04.01-ways-to-use-trellis |

## agent-harness docs/scenarios.md

| Source heading | Covered in |
|---|---|
| What to wrap | 04.15-common-scenarios |
| Where a tool comes from | 04.15-common-scenarios |
| Memory: reading and writing | 04.15-common-scenarios |
| Pausing for a person | 04.15-common-scenarios |
| Running it | 04.15-common-scenarios |
| Time, failures and cancelling | 04.15-common-scenarios |
| Local or agent-runs | 04.15-common-scenarios |
| AG-UI or A2A | 04.15-common-scenarios |
| Seeing what happened | 04.15-common-scenarios |
| Evaluating it | 04.15-common-scenarios |

## agent-harness docs/onboarding.md

| Source heading | Covered in |
|---|---|
| 1. The operator creates the tenant | 03.4-deploy-and-onboard |
| 2. The tenant's admin issues the application's key | 03.4-deploy-and-onboard |
| 3. Configure the application and its workers | 03.4-deploy-and-onboard |
| 4. Optional: a key per person, for an approvals UI | 03.4-deploy-and-onboard |

## agent-harness docs/blocks/*.md

| Source heading | Covered in |
|---|---|
| mixing.md: What is shared, Answering each run its own way, Workers, Calling across, Do not gate twice, Moving between the ways, The records they share | 04.01-ways-to-use-trellis |
| memory.md: Install and set up, One turn, Recording tool calls, Behaviour | 04.01-ways-to-use-trellis (example), 03.2-install |
| runs.md: Install, Workers, Schedules, Webhooks | 04.01-ways-to-use-trellis, 10.2-settings-reference (RunsClient arguments) |
| governance.md: The API, governed, Where your framework asks | 04.01-ways-to-use-trellis, 10.1-api-cheatsheet |
| evaluation.md: evaluate, judge | 10.1-api-cheatsheet, 04.15-common-scenarios |
| a2a.md: RemoteAgent | 10.1-api-cheatsheet, 04.01-ways-to-use-trellis |

## agent-harness docs/matrix.md

| Source rows | Covered in |
|---|---|
| Every Way 1 and Way 2 row (F02 to F75r, SEL, X01 to X17) | 10.3-feature-checklist (one row each) |
| What the Kimi Code (ACP) column does not show | 10.3-feature-checklist (Good to know) |

## agent-memory-service README.md, docs/configuration.md, docs/guide/11-operations.md, docs/deploy/

| Source heading | Covered in |
|---|---|
| Install and run | 03.2-install, 03.4-deploy-and-onboard |
| Where this fits | 01-home, 04.01-ways-to-use-trellis |
| What you get (memory kinds, guarantees) | 10.3-feature-checklist, 02-glossary |
| How it is read, What is automatic | 10.2-settings-reference |
| Service, Database, Cache, Background jobs, Authentication, Authorization, Blob storage, Search, The model endpoint, Observability, The customer's calendar, Other environment variables | 10.2-settings-reference |
| Production guards | 03.4-deploy-and-onboard, 10.2-settings-reference |
| Deploying: the compose stack, what a production deployment changes | 03.4-deploy-and-onboard |
| deploy/database.md (connection budget, migrations) | 10.2-settings-reference (settings only; details for 09.x) |

## agent-runs README.md, docs/configuration.md

| Source heading | Covered in |
|---|---|
| Where this fits | 01-home, 04.01-ways-to-use-trellis |
| When to use what | 10.3-feature-checklist (agent-runs rows) |
| Who may answer a paused run | 03.4-deploy-and-onboard |
| Run it | 03.4-deploy-and-onboard, 03.2-install |
| Every `RUNS__*` setting, Outside the service | 10.2-settings-reference |

## agent-contracts and bifrost-sdk docs/configuration.md

| Source heading | Covered in |
|---|---|
| contracts: no settings, record defaults, constants | 10.2-settings-reference |
| bifrost-sdk: Bifrost(...), Admin(...), Options, Fixed in code, names the other repos use, live tests | 10.2-settings-reference |

## Things found in the sources that disagree with the code (written from the code)

- harness `docs/scenarios.md` uses `timeout=` on `h.wrap`, `run`, `start` and `openapi`/`a2a`;
  the code's names are `run_timeout=` and `call_timeout=`. The pages use the code's names.
- harness `README.md` says `LANGFUSE_HOST`; `docs/configuration.md` and the code use
  `LANGFUSE_BASE_URL` (`LANGFUSE_HOST` is retired). The pages use `LANGFUSE_BASE_URL`.
- harness `docs/blocks/evaluation.md` mentions `Settings.from_env().eval_sample`
  (`TRELLIS_EVAL_SAMPLE`); `Settings` has no such field. Left out.
- harness `src/trellis/harness/worker/__main__.py` help text still names
  `TRELLIS_WORKER_CONCURRENCY`, which nothing reads. The pages say it is retired.
- harness `README.md` lists fewer extras than `pyproject.toml` (missing `kimi`, `mcp`, `xlsx`,
  `anthropic`, `gemini`, `vertex`, `bedrock`). 03.2-install lists the `pyproject.toml` set.
- `trellis.middleware` and `trellis.Citation` are exported by `trellis/__init__.py` but missing
  from the import list at the top of `docs/api.md`. 10.1-api-cheatsheet includes them.
